// API Types
export interface User {
  id: number;
  username: string;
  role: 'admin' | 'pm' | 'procurement' | 'finance';
  created_at: string;
  is_active: boolean;
}

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface Token {
  access_token: string;
  token_type: string;
}

export interface Project {
  id: number;
  project_code: string;
  name: string;
  created_at: string;
  is_active: boolean;
}

export interface ProjectSummary {
  id: number;
  project_code: string;
  name: string;
  item_count: number;
  total_quantity: number;
  estimated_cost: number;
}

export interface ProjectItem {
  id: number;
  project_id: number;
  item_code: string;
  item_name: string | null;
  quantity: number;
  must_buy_time: number | null;
  allowed_times: string;
  external_purchase: boolean;
  created_at: string;
  updated_at: string | null;
}

export interface ProjectItemCreate {
  project_id: number;
  item_code: string;
  item_name?: string;
  quantity: number;
  must_buy_time?: number;
  allowed_times: string;
  external_purchase?: boolean;
}

export interface ProjectItemUpdate {
  item_code?: string;
  item_name?: string;
  quantity?: number;
  must_buy_time?: number;
  allowed_times?: string;
  external_purchase?: boolean;
}

export interface PaymentTermsCash {
  type: 'cash';
  discount_percent?: number;
}

export interface PaymentTermsInstallments {
  type: 'installments';
  schedule: Array<{
    due_offset: number;
    percent: number;
  }>;
}

export type PaymentTerms = PaymentTermsCash | PaymentTermsInstallments;

export interface ProcurementOption {
  id: number;
  item_code: string;
  supplier_name: string;
  base_cost: number;
  lomc_lead_time: number;
  discount_bundle_threshold: number | null;
  discount_bundle_percent: number | null;
  payment_terms: PaymentTerms;
  created_at: string;
  updated_at: string | null;
  is_active: boolean;
}

export interface ProcurementOptionCreate {
  item_code: string;
  supplier_name: string;
  base_cost: number;
  lomc_lead_time?: number;
  discount_bundle_threshold?: number;
  discount_bundle_percent?: number;
  payment_terms: PaymentTerms;
}

export interface ProcurementOptionUpdate {
  item_code?: string;
  supplier_name?: string;
  base_cost?: number;
  lomc_lead_time?: number;
  discount_bundle_threshold?: number;
  discount_bundle_percent?: number;
  payment_terms?: PaymentTerms;
  is_active?: boolean;
}

export interface BudgetData {
  id: number;
  time_slot: number;
  available_budget: number;
  created_at: string;
  updated_at: string | null;
}

export interface BudgetDataCreate {
  time_slot: number;
  available_budget: number;
}

export interface BudgetDataUpdate {
  time_slot?: number;
  available_budget?: number;
}

export interface OptimizationResult {
  id: number;
  run_id: string;
  run_timestamp: string;
  project_id: number | null;
  item_code: string;
  procurement_option_id: number;
  purchase_time: number;
  delivery_time: number;
  quantity: number;
  final_cost: number;
}

export interface OptimizationRunRequest {
  max_time_slots?: number;
  time_limit_seconds?: number;
}

export interface OptimizationRunResponse {
  run_id: string;
  status: string;
  total_cost: number;
  items_optimized: number;
  execution_time_seconds: number;
  message?: string;
}

export interface DashboardStats {
  total_projects: number;
  total_items: number;
  total_procurement_options: number;
  total_budget: number;
  last_optimization: string | null;
  pending_items: number;
}

export interface ExcelImportResponse {
  success: boolean;
  imported_count: number;
  errors: string[];
  message: string;
}

// UI Types
export interface TableColumn {
  id: string;
  label: string;
  minWidth?: number;
  align?: 'right' | 'left' | 'center';
  format?: (value: any) => string;
}

export interface FormField {
  name: string;
  label: string;
  type: 'text' | 'number' | 'email' | 'password' | 'select' | 'checkbox' | 'textarea';
  required?: boolean;
  options?: Array<{ value: any; label: string }>;
  multiline?: boolean;
  rows?: number;
}
