import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Alert,
  CircularProgress,
  Card,
  CardContent,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Chip,
  Grid,
  LinearProgress,
} from '@mui/material';
import {
  PlayArrow as PlayArrowIcon,
  Refresh as RefreshIcon,
  TrendingUp as TrendingUpIcon,
  Schedule as ScheduleIcon,
  AttachMoney as AttachMoneyIcon,
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext.tsx';
import { financeAPI } from '../services/api.ts';
import { OptimizationResult, OptimizationRunResponse } from '../types/index.ts';

export const OptimizationPage: React.FC = () => {
  const { user } = useAuth();
  const [results, setResults] = useState<OptimizationResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [optimizing, setOptimizing] = useState(false);
  const [error, setError] = useState('');
  const [runDialogOpen, setRunDialogOpen] = useState(false);
  const [optimizationConfig, setOptimizationConfig] = useState({
    max_time_slots: 12,
    time_limit_seconds: 300,
  });
  const [lastRun, setLastRun] = useState<OptimizationRunResponse | null>(null);

  useEffect(() => {
    fetchResults();
    fetchLatestRun();
  }, []);

  const fetchResults = async () => {
    try {
      const response = await financeAPI.listResults();
      setResults(response.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to load optimization results');
    } finally {
      setLoading(false);
    }
  };

  const fetchLatestRun = async () => {
    try {
      const response = await financeAPI.getLatestRun();
      // Check if response has the expected structure
      if (response.data && typeof response.data === 'object') {
        // If it only has run_id, it's incomplete - skip it
        if (Object.keys(response.data).length === 1 && 'run_id' in response.data) {
          return;
        }
        setLastRun(response.data);
      }
    } catch (err: any) {
      // No previous runs
    }
  };

  const handleRunOptimization = async () => {
    setOptimizing(true);
    setError('');

    try {
      const response = await financeAPI.runOptimization(optimizationConfig);
      setLastRun(response.data);
      setRunDialogOpen(false);
      fetchResults();
      
      if (response.data.status === 'OPTIMAL' || response.data.status === 'FEASIBLE') {
        alert(`Optimization completed successfully!\nTotal Cost: $${response.data.total_cost.toLocaleString()}\nItems Optimized: ${response.data.items_optimized}`);
      } else {
        alert(`Optimization failed: ${response.data.message}`);
      }
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Optimization failed');
    } finally {
      setOptimizing(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OPTIMAL':
        return 'success';
      case 'FEASIBLE':
        return 'warning';
      case 'INFEASIBLE':
        return 'error';
      default:
        return 'default';
    }
  };

  // Group results by run
  const groupedResults = results.reduce((acc, result) => {
    const runId = result.run_id;
    if (!acc[runId]) {
      acc[runId] = {
        run_id: runId,
        run_timestamp: result.run_timestamp,
        results: [],
        total_cost: 0,
      };
    }
    acc[runId].results.push(result);
    acc[runId].total_cost += result.final_cost;
    return acc;
  }, {} as Record<string, any>);

  const runIds = Object.keys(groupedResults).sort((a, b) => 
    new Date(groupedResults[b].run_timestamp).getTime() - new Date(groupedResults[a].run_timestamp).getTime()
  );

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4">Optimization Results</Typography>
        {(user?.role === 'finance' || user?.role === 'admin') && (
          <Button
            variant="contained"
            startIcon={<PlayArrowIcon />}
            onClick={() => setRunDialogOpen(true)}
            disabled={optimizing}
          >
            {optimizing ? 'Running...' : 'Run Optimization'}
          </Button>
        )}
      </Box>

      {optimizing && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Box display="flex" alignItems="center" mb={2}>
              <CircularProgress size={20} sx={{ mr: 2 }} />
              <Typography variant="h6">Running Optimization...</Typography>
            </Box>
            <LinearProgress />
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              This may take several minutes depending on the problem size.
            </Typography>
          </CardContent>
        </Card>
      )}

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
          {error}
        </Alert>
      )}

      {lastRun && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Latest Optimization Run
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6} md={3}>
                <Box display="flex" alignItems="center">
                  <TrendingUpIcon sx={{ mr: 1, color: 'text.secondary' }} />
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Status
                    </Typography>
                    <Chip 
                      label={lastRun.status} 
                      color={getStatusColor(lastRun.status) as any}
                      size="small"
                    />
                  </Box>
                </Box>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Box display="flex" alignItems="center">
                  <AttachMoneyIcon sx={{ mr: 1, color: 'text.secondary' }} />
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Total Cost
                    </Typography>
                    <Typography variant="h6">
                      {formatCurrency(lastRun.total_cost)}
                    </Typography>
                  </Box>
                </Box>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Box display="flex" alignItems="center">
                  <ScheduleIcon sx={{ mr: 1, color: 'text.secondary' }} />
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Items Optimized
                    </Typography>
                    <Typography variant="h6">
                      {lastRun.items_optimized}
                    </Typography>
                  </Box>
                </Box>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Execution Time
                  </Typography>
                  <Typography variant="h6">
                    {lastRun.execution_time_seconds ? lastRun.execution_time_seconds.toFixed(1) : '0.0'}s
                  </Typography>
                </Box>
              </Grid>
            </Grid>
            {lastRun.message && (
              <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                {lastRun.message}
              </Typography>
            )}
          </CardContent>
        </Card>
      )}

      {runIds.length === 0 ? (
        <Card>
          <CardContent>
            <Typography variant="h6" color="text.secondary" align="center">
              No optimization results available
            </Typography>
            <Typography variant="body2" color="text.secondary" align="center">
              Run an optimization to see results here
            </Typography>
          </CardContent>
        </Card>
      ) : (
        runIds.map((runId) => {
          const run = groupedResults[runId];
          return (
            <Card key={runId} sx={{ mb: 3 }}>
              <CardContent>
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                  <Typography variant="h6">
                    Run {runId.slice(0, 8)}...
                  </Typography>
                  <Box display="flex" gap={1}>
                    <Chip 
                      label={formatCurrency(run.total_cost)}
                      color="primary"
                      variant="outlined"
                    />
                    <Chip 
                      label={`${run.results.length} items`}
                      color="secondary"
                      variant="outlined"
                    />
                  </Box>
                </Box>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  {formatDate(run.run_timestamp)}
                </Typography>

                <TableContainer component={Paper} sx={{ mt: 2 }}>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Project</TableCell>
                        <TableCell>Item Code</TableCell>
                        <TableCell>Purchase Time</TableCell>
                        <TableCell>Delivery Time</TableCell>
                        <TableCell align="right">Quantity</TableCell>
                        <TableCell align="right">Cost</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {run.results.map((result: OptimizationResult) => (
                        <TableRow key={result.id}>
                          <TableCell>
                            {result.project_id ? `Project ${result.project_id}` : '-'}
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" fontWeight="medium">
                              {result.item_code}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Chip label={`Period ${result.purchase_time}`} size="small" />
                          </TableCell>
                          <TableCell>
                            <Chip label={`Period ${result.delivery_time}`} size="small" color="primary" />
                          </TableCell>
                          <TableCell align="right">{result.quantity}</TableCell>
                          <TableCell align="right">
                            <Typography variant="body2" fontWeight="medium">
                              {formatCurrency(result.final_cost)}
                            </Typography>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </CardContent>
            </Card>
          );
        })
      )}

      {/* Run Optimization Dialog */}
      <Dialog open={runDialogOpen} onClose={() => setRunDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Run Optimization</DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" paragraph>
            Configure the optimization parameters and run the procurement optimization.
          </Typography>
          <TextField
            autoFocus
            margin="dense"
            label="Maximum Time Slots"
            type="number"
            fullWidth
            variant="outlined"
            value={optimizationConfig.max_time_slots}
            onChange={(e) => setOptimizationConfig({
              ...optimizationConfig,
              max_time_slots: parseInt(e.target.value) || 12
            })}
            sx={{ mb: 2 }}
            helperText="Maximum number of time periods to consider"
          />
          <TextField
            margin="dense"
            label="Time Limit (seconds)"
            type="number"
            fullWidth
            variant="outlined"
            value={optimizationConfig.time_limit_seconds}
            onChange={(e) => setOptimizationConfig({
              ...optimizationConfig,
              time_limit_seconds: parseInt(e.target.value) || 300
            })}
            helperText="Maximum time to spend on optimization"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRunDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleRunOptimization} variant="contained" disabled={optimizing}>
            {optimizing ? 'Running...' : 'Run Optimization'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
