import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext.tsx';
import { ProtectedRoute } from './components/ProtectedRoute.tsx';
import { Layout } from './components/Layout.tsx';
import { LoginPage } from './pages/LoginPage.tsx';
import { DashboardPage } from './pages/DashboardPage.tsx';
import { ProjectsPage } from './pages/ProjectsPage.tsx';
import { ProjectItemsPage } from './pages/ProjectItemsPage.tsx';
import { ProcurementPage } from './pages/ProcurementPage.tsx';
import { FinancePage } from './pages/FinancePage.tsx';
import { OptimizationPage } from './pages/OptimizationPage.tsx';
import { UsersPage } from './pages/UsersPage.tsx';

function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route
          path="/*"
          element={
            <ProtectedRoute>
              <Layout>
                <Routes>
                  <Route path="/" element={<Navigate to="/dashboard" replace />} />
                  <Route path="/dashboard" element={<DashboardPage />} />
                  <Route path="/projects" element={<ProjectsPage />} />
                  <Route path="/projects/:projectId/items" element={<ProjectItemsPage />} />
                  <Route path="/procurement" element={<ProcurementPage />} />
                  <Route path="/finance" element={<FinancePage />} />
                  <Route path="/optimization" element={<OptimizationPage />} />
                  <Route path="/users" element={<UsersPage />} />
                </Routes>
              </Layout>
            </ProtectedRoute>
          }
        />
      </Routes>
    </AuthProvider>
  );
}

export default App;
