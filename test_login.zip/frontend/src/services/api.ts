import axios from 'axios';

// Configure axios
// Note: In development, the proxy in package.json handles routing to the backend
// In production, set REACT_APP_API_URL to the actual backend URL
const API_BASE_URL = process.env.REACT_APP_API_URL || '';
console.log('API Base URL:', API_BASE_URL || '(using proxy from package.json)');

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add request interceptor to include auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor to handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: (credentials: { username: string; password: string }) =>
    api.post('/auth/login', credentials),
  me: () => api.get('/auth/me'),
  refresh: () => api.post('/auth/refresh'),
};

// Users API
export const usersAPI = {
  list: (params?: { skip?: number; limit?: number }) =>
    api.get('/users/', { params }),
  get: (id: number) => api.get(`/users/${id}`),
  create: (user: any) => api.post('/users/', user),
  update: (id: number, user: any) => api.put(`/users/${id}`, user),
  delete: (id: number) => api.delete(`/users/${id}`),
};

// Projects API
export const projectsAPI = {
  list: (params?: { skip?: number; limit?: number }) =>
    api.get('/projects/', { params }),
  get: (id: number) => api.get(`/projects/${id}`),
  create: (project: any) => api.post('/projects/', project),
  update: (id: number, project: any) => api.put(`/projects/${id}`, project),
  delete: (id: number) => api.delete(`/projects/${id}`),
  assignUser: (assignment: { user_id: number; project_id: number }) =>
    api.post('/projects/assignments', assignment),
  removeUser: (userId: number, projectId: number) =>
    api.delete(`/projects/assignments/${userId}/${projectId}`),
  getUserAssignments: (userId: number) =>
    api.get(`/projects/assignments/${userId}`),
};

// Project Items API
export const itemsAPI = {
  listByProject: (projectId: number, params?: { skip?: number; limit?: number }) =>
    api.get(`/items/project/${projectId}`, { params }),
  get: (id: number) => api.get(`/items/${id}`),
  create: (item: any) => api.post('/items/', item),
  update: (id: number, item: any) => api.put(`/items/${id}`, item),
  delete: (id: number) => api.delete(`/items/${id}`),
};

// Procurement API
export const procurementAPI = {
  getItemCodes: () => api.get('/procurement/item-codes'),
  listOptions: (params?: { skip?: number; limit?: number; item_code?: string }) =>
    api.get('/procurement/options', { params }),
  listByItemCode: (itemCode: string) =>
    api.get(`/procurement/options/${itemCode}`),
  get: (id: number) => api.get(`/procurement/option/${id}`),
  create: (option: any) => api.post('/procurement/options', option),
  update: (id: number, option: any) => api.put(`/procurement/option/${id}`, option),
  delete: (id: number) => api.delete(`/procurement/option/${id}`),
};

// Finance API
export const financeAPI = {
  getDashboard: () => api.get('/finance/dashboard'),
  listBudget: () => api.get('/finance/budget'),
  createBudget: (budget: any) => api.post('/finance/budget', budget),
  getBudget: (timeSlot: number) => api.get(`/finance/budget/${timeSlot}`),
  updateBudget: (timeSlot: number, budget: any) =>
    api.put(`/finance/budget/${timeSlot}`, budget),
  deleteBudget: (timeSlot: number) => api.delete(`/finance/budget/${timeSlot}`),
  runOptimization: (request: any) => api.post('/finance/optimize', request),
  listResults: (params?: { run_id?: string; skip?: number; limit?: number }) =>
    api.get('/finance/optimization-results', { params }),
  getResults: (runId: string) => api.get(`/finance/optimization-results/${runId}`),
  getLatestRun: () => api.get('/finance/latest-optimization'),
};

// Excel API
export const excelAPI = {
  // Project Items
  downloadItemsTemplate: () => api.get('/excel/templates/items', { responseType: 'blob' }),
  exportItems: (projectId?: number) =>
    api.get('/excel/export/items', { 
      params: projectId ? { project_id: projectId } : {},
      responseType: 'blob'
    }),
  importItems: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/excel/import/items', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  
  // Procurement Options
  downloadProcurementTemplate: () => 
    api.get('/excel/templates/procurement', { responseType: 'blob' }),
  exportProcurement: (itemCode?: string) =>
    api.get('/excel/export/procurement', { 
      params: itemCode ? { item_code: itemCode } : {},
      responseType: 'blob'
    }),
  importProcurement: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/excel/import/procurement', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  
  // Budget Data
  downloadBudgetTemplate: () => 
    api.get('/excel/templates/budget', { responseType: 'blob' }),
  exportBudget: () => api.get('/excel/export/budget', { responseType: 'blob' }),
  importBudget: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/excel/import/budget', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
};

export default api;
