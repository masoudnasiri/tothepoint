"""
Finance and optimization endpoints
"""

from typing import List
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.auth import get_current_user, require_finance
from app.crud import (
    create_budget_data, get_budget_data, get_all_budget_data,
    update_budget_data, delete_budget_data, get_optimization_results,
    get_latest_optimization_run, get_dashboard_stats
)
from app.optimization_engine import ProcurementOptimizer
from app.excel_handler import ExcelHandler
from app.models import User
from app.schemas import (
    BudgetData, BudgetDataCreate, BudgetDataUpdate,
    OptimizationResult, OptimizationRunRequest, OptimizationRunResponse,
    DashboardStats, ExcelImportResponse
)

router = APIRouter(prefix="/finance", tags=["finance"])


@router.get("/dashboard", response_model=DashboardStats)
async def get_finance_dashboard(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get finance dashboard statistics"""
    return await get_dashboard_stats(db)


@router.get("/budget", response_model=List[BudgetData])
async def list_budget_data(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get all budget data"""
    return await get_all_budget_data(db)


@router.post("/budget", response_model=BudgetData)
async def create_new_budget_data(
    budget: BudgetDataCreate,
    current_user: User = Depends(require_finance()),
    db: AsyncSession = Depends(get_db)
):
    """Create new budget data (finance user only)"""
    # Check if budget for this time slot already exists
    existing = await get_budget_data(db, budget.time_slot)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Budget data for time slot {budget.time_slot} already exists"
        )
    
    return await create_budget_data(db, budget)


@router.get("/budget/{time_slot}", response_model=BudgetData)
async def get_budget_data_by_time_slot(
    time_slot: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get budget data by time slot"""
    budget = await get_budget_data(db, time_slot)
    if not budget:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Budget data not found"
        )
    return budget


@router.put("/budget/{time_slot}", response_model=BudgetData)
async def update_budget_data_by_time_slot(
    time_slot: int,
    budget_update: BudgetDataUpdate,
    current_user: User = Depends(require_finance()),
    db: AsyncSession = Depends(get_db)
):
    """Update budget data (finance user only)"""
    budget = await update_budget_data(db, time_slot, budget_update)
    if not budget:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Budget data not found"
        )
    return budget


@router.delete("/budget/{time_slot}")
async def delete_budget_data_by_time_slot(
    time_slot: int,
    current_user: User = Depends(require_finance()),
    db: AsyncSession = Depends(get_db)
):
    """Delete budget data (finance user only)"""
    success = await delete_budget_data(db, time_slot)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Budget data not found"
        )
    return {"message": "Budget data deleted successfully"}


@router.post("/optimize", response_model=OptimizationRunResponse)
async def run_optimization(
    request: OptimizationRunRequest,
    current_user: User = Depends(require_finance()),
    db: AsyncSession = Depends(get_db)
):
    """Run procurement optimization (finance user only)"""
    optimizer = ProcurementOptimizer(db)
    return await optimizer.run_optimization(request)


@router.get("/optimization-results", response_model=List[OptimizationResult])
async def list_optimization_results(
    run_id: str = None,
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get optimization results"""
    return await get_optimization_results(db, run_id=run_id, skip=skip, limit=limit)


@router.get("/optimization-results/{run_id}", response_model=List[OptimizationResult])
async def get_optimization_results_by_run_id(
    run_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get optimization results for a specific run"""
    return await get_optimization_results(db, run_id=run_id)


@router.get("/latest-optimization")
async def get_latest_optimization_run_id(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get the latest optimization run ID"""
    run_id = await get_latest_optimization_run(db)
    if not run_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No optimization runs found"
        )
    return {"run_id": run_id}


# Excel import/export endpoints
@router.post("/import/budget", response_model=ExcelImportResponse)
async def import_budget_data_from_excel(
    file: UploadFile = File(...),
    current_user: User = Depends(require_finance()),
    db: AsyncSession = Depends(get_db)
):
    """Import budget data from Excel file (finance user only)"""
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="File must be an Excel file (.xlsx or .xls)"
        )
    
    content = await file.read()
    return await ExcelHandler.import_budget_data(db, content)


@router.get("/export/budget")
async def export_budget_data_to_excel(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Export budget data to Excel file"""
    excel_data = await ExcelHandler.export_budget_data(db)
    
    return StreamingResponse(
        BytesIO(excel_data),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=budget_data.xlsx"}
    )


@router.get("/templates/budget")
async def download_budget_template():
    """Download budget data Excel template"""
    template_data = ExcelHandler.create_budget_template()
    
    return StreamingResponse(
        BytesIO(template_data),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=budget_template.xlsx"}
    )
