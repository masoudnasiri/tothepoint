from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any, Union, Literal
from datetime import datetime
from decimal import Decimal
import uuid


# User Schemas
class UserBase(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    role: str = Field(..., pattern="^(admin|pm|procurement|finance)$")


class UserCreate(UserBase):
    password: str = Field(..., min_length=6)


class UserUpdate(BaseModel):
    username: Optional[str] = Field(None, min_length=3, max_length=50)
    role: Optional[str] = Field(None, pattern="^(admin|pm|procurement|finance)$")
    is_active: Optional[bool] = None


class User(UserBase):
    id: int
    created_at: datetime
    is_active: bool
    
    model_config = {"from_attributes": True}


class UserLogin(BaseModel):
    username: str
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str


# Project Schemas
class ProjectBase(BaseModel):
    project_code: str = Field(..., min_length=1, max_length=50)
    name: str = Field(..., min_length=1)


class ProjectCreate(ProjectBase):
    pass


class ProjectUpdate(BaseModel):
    project_code: Optional[str] = Field(None, min_length=1, max_length=50)
    name: Optional[str] = Field(None, min_length=1)
    is_active: Optional[bool] = None


class Project(ProjectBase):
    id: int
    created_at: datetime
    is_active: bool
    
    model_config = {"from_attributes": True}


class ProjectAssignmentCreate(BaseModel):
    user_id: int
    project_id: int


class ProjectAssignment(BaseModel):
    user_id: int
    project_id: int
    assigned_at: datetime
    
    model_config = {"from_attributes": True}


# Project Item Schemas
class ProjectItemBase(BaseModel):
    item_code: str = Field(..., min_length=1, max_length=50)
    item_name: Optional[str] = None
    quantity: int = Field(..., gt=0)
    must_buy_time: Optional[int] = Field(None, ge=1)
    allowed_times: str = Field(..., min_length=1)  # e.g., '1,2,4'
    external_purchase: bool = False
    
    @validator('allowed_times')
    def validate_allowed_times(cls, v):
        try:
            times = [int(t.strip()) for t in v.split(',')]
            if not all(t >= 1 for t in times):
                raise ValueError('All time slots must be >= 1')
            return v
        except ValueError:
            raise ValueError('allowed_times must be comma-separated integers')


class ProjectItemCreate(ProjectItemBase):
    project_id: int


class ProjectItemUpdate(BaseModel):
    item_code: Optional[str] = Field(None, min_length=1, max_length=50)
    item_name: Optional[str] = None
    quantity: Optional[int] = Field(None, gt=0)
    must_buy_time: Optional[int] = Field(None, ge=1)
    allowed_times: Optional[str] = Field(None, min_length=1)
    external_purchase: Optional[bool] = None


class ProjectItem(ProjectItemBase):
    id: int
    project_id: int
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    model_config = {"from_attributes": True}


# Procurement Option Schemas
class PaymentTermsCash(BaseModel):
    type: Literal["cash"] = "cash"
    discount_percent: Optional[Decimal] = Field(None, ge=0, le=100)


class PaymentTermsInstallments(BaseModel):
    type: Literal["installments"] = "installments"
    schedule: List[Dict[str, Union[int, Decimal]]] = Field(..., min_items=1)
    
    @validator('schedule')
    def validate_schedule(cls, v):
        total_percent = sum(installment.get('percent', 0) for installment in v)
        if abs(total_percent - 100) > 0.01:  # Allow small floating point differences
            raise ValueError('Schedule percentages must sum to 100')
        
        for i, installment in enumerate(v):
            if 'due_offset' not in installment or 'percent' not in installment:
                raise ValueError(f'Installment {i} must have due_offset and percent')
            if installment['due_offset'] < 0:
                raise ValueError(f'Installment {i} due_offset must be >= 0')
            if not (0 <= installment['percent'] <= 100):
                raise ValueError(f'Installment {i} percent must be between 0 and 100')
        
        return v


class ProcurementOptionBase(BaseModel):
    item_code: str = Field(..., min_length=1, max_length=50)
    supplier_name: str = Field(..., min_length=1)
    base_cost: Decimal = Field(..., gt=0)
    lomc_lead_time: int = Field(0, ge=0)
    discount_bundle_threshold: Optional[int] = Field(None, gt=0)
    discount_bundle_percent: Optional[Decimal] = Field(None, ge=0, le=100)
    payment_terms: Union[PaymentTermsCash, PaymentTermsInstallments]


class ProcurementOptionCreate(ProcurementOptionBase):
    pass


class ProcurementOptionUpdate(BaseModel):
    item_code: Optional[str] = Field(None, min_length=1, max_length=50)
    supplier_name: Optional[str] = Field(None, min_length=1)
    base_cost: Optional[Decimal] = Field(None, gt=0)
    lomc_lead_time: Optional[int] = Field(None, ge=0)
    discount_bundle_threshold: Optional[int] = Field(None, gt=0)
    discount_bundle_percent: Optional[Decimal] = Field(None, ge=0, le=100)
    payment_terms: Optional[Union[PaymentTermsCash, PaymentTermsInstallments]]
    is_active: Optional[bool] = None


class ProcurementOption(ProcurementOptionBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None
    is_active: bool
    
    model_config = {"from_attributes": True}


# Budget Data Schemas
class BudgetDataBase(BaseModel):
    time_slot: int = Field(..., ge=1)
    available_budget: Decimal = Field(..., ge=0)


class BudgetDataCreate(BudgetDataBase):
    pass


class BudgetDataUpdate(BaseModel):
    time_slot: Optional[int] = Field(None, ge=1)
    available_budget: Optional[Decimal] = Field(None, ge=0)


class BudgetData(BudgetDataBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    model_config = {"from_attributes": True}


# Optimization Result Schemas
class OptimizationResult(BaseModel):
    id: int
    run_id: uuid.UUID
    run_timestamp: datetime
    project_id: Optional[int]
    item_code: str
    procurement_option_id: int
    purchase_time: int
    delivery_time: int
    quantity: int
    final_cost: Decimal
    
    model_config = {"from_attributes": True}


class OptimizationRunRequest(BaseModel):
    max_time_slots: int = Field(12, ge=1, le=100)
    time_limit_seconds: int = Field(300, ge=10, le=3600)


class OptimizationRunResponse(BaseModel):
    run_id: uuid.UUID
    status: str
    total_cost: Decimal
    items_optimized: int
    execution_time_seconds: float
    message: Optional[str] = None


# Excel Import/Export Schemas
class ExcelImportResponse(BaseModel):
    success: bool
    imported_count: int
    errors: List[str] = []
    message: str


# Dashboard Schemas
class DashboardStats(BaseModel):
    total_projects: int
    total_items: int
    total_procurement_options: int
    total_budget: Decimal
    last_optimization: Optional[datetime] = None
    pending_items: int = 0


class ProjectSummary(BaseModel):
    id: int
    project_code: str
    name: str
    item_count: int
    total_quantity: int
    estimated_cost: Optional[Decimal] = None
