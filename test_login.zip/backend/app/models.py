from sqlalchemy import Column, Integer, String, Text, Boolean, Numeric, DateTime, ForeignKey, JSON
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
from app.database import Base


class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False)  # 'admin', 'pm', 'procurement', 'finance'
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    is_active = Column(Boolean, default=True)
    
    # Relationships
    project_assignments = relationship("ProjectAssignment", back_populates="user", cascade="all, delete-orphan")


class Project(Base):
    __tablename__ = "projects"
    
    id = Column(Integer, primary_key=True, index=True)
    project_code = Column(String(50), unique=True, index=True, nullable=False)
    name = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    is_active = Column(Boolean, default=True)
    
    # Relationships
    project_items = relationship("ProjectItem", back_populates="project", cascade="all, delete-orphan")
    project_assignments = relationship("ProjectAssignment", back_populates="project", cascade="all, delete-orphan")
    optimization_results = relationship("OptimizationResult", back_populates="project")


class ProjectAssignment(Base):
    __tablename__ = "project_assignments"
    
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), primary_key=True)
    assigned_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    user = relationship("User", back_populates="project_assignments")
    project = relationship("Project", back_populates="project_assignments")


class ProjectItem(Base):
    __tablename__ = "project_items"
    
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    item_code = Column(String(50), nullable=False)
    item_name = Column(Text)
    quantity = Column(Integer, nullable=False)
    must_buy_time = Column(Integer)  # Specific required delivery time slot
    allowed_times = Column(Text, nullable=False)  # e.g., '1,2,4' for allowed delivery time slots
    external_purchase = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    project = relationship("Project", back_populates="project_items")


class ProcurementOption(Base):
    __tablename__ = "procurement_options"
    
    id = Column(Integer, primary_key=True, index=True)
    item_code = Column(String(50), nullable=False, index=True)
    supplier_name = Column(Text, nullable=False)
    base_cost = Column(Numeric(12, 2), nullable=False)
    lomc_lead_time = Column(Integer, default=0)  # Lead time in time slots
    discount_bundle_threshold = Column(Integer)
    discount_bundle_percent = Column(Numeric(5, 2))
    payment_terms = Column(JSON, nullable=False)  # Structured JSON for payment terms
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    is_active = Column(Boolean, default=True)
    
    # Relationships
    optimization_results = relationship("OptimizationResult", back_populates="procurement_option")


class BudgetData(Base):
    __tablename__ = "budget_data"
    
    id = Column(Integer, primary_key=True, index=True)
    time_slot = Column(Integer, unique=True, nullable=False, index=True)
    available_budget = Column(Numeric(15, 2), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class OptimizationResult(Base):
    __tablename__ = "optimization_results"
    
    id = Column(Integer, primary_key=True, index=True)
    run_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    run_timestamp = Column(DateTime(timezone=True), server_default=func.now())
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    item_code = Column(String(50), nullable=False)
    procurement_option_id = Column(Integer, ForeignKey("procurement_options.id"), nullable=False)
    purchase_time = Column(Integer, nullable=False)  # The time slot the purchase decision is made
    delivery_time = Column(Integer, nullable=False)  # The time slot the item is delivered
    quantity = Column(Integer, nullable=False)
    final_cost = Column(Numeric(12, 2), nullable=False)
    
    # Relationships
    project = relationship("Project", back_populates="optimization_results")
    procurement_option = relationship("ProcurementOption", back_populates="optimization_results")
