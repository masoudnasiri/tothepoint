"""
CRUD operations for database interactions
"""

from typing import List, Optional, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete, func, and_, or_
from sqlalchemy.orm import selectinload
from app.models import (
    User, Project, ProjectAssignment, ProjectItem, 
    ProcurementOption, BudgetData, OptimizationResult
)
from app.schemas import (
    UserCreate, UserUpdate, ProjectCreate, ProjectUpdate,
    ProjectItemCreate, ProjectItemUpdate, ProcurementOptionCreate,
    ProcurementOptionUpdate, BudgetDataCreate, BudgetDataUpdate
)
from app.auth import get_password_hash
import logging

logger = logging.getLogger(__name__)


# User CRUD operations
async def create_user(db: AsyncSession, user: UserCreate) -> User:
    """Create a new user"""
    hashed_password = get_password_hash(user.password)
    db_user = User(
        username=user.username,
        password_hash=hashed_password,
        role=user.role
    )
    db.add(db_user)
    await db.commit()
    await db.refresh(db_user)
    return db_user


async def get_user(db: AsyncSession, user_id: int) -> Optional[User]:
    """Get user by ID"""
    result = await db.execute(select(User).where(User.id == user_id))
    return result.scalar_one_or_none()


async def get_users(db: AsyncSession, skip: int = 0, limit: int = 100) -> List[User]:
    """Get list of users with pagination"""
    result = await db.execute(
        select(User).offset(skip).limit(limit).order_by(User.created_at.desc())
    )
    return result.scalars().all()


async def update_user(db: AsyncSession, user_id: int, user_update: UserUpdate) -> Optional[User]:
    """Update user"""
    update_data = user_update.dict(exclude_unset=True)
    if not update_data:
        return await get_user(db, user_id)
    
    await db.execute(
        update(User).where(User.id == user_id).values(**update_data)
    )
    await db.commit()
    return await get_user(db, user_id)


async def delete_user(db: AsyncSession, user_id: int) -> bool:
    """Delete user"""
    result = await db.execute(delete(User).where(User.id == user_id))
    await db.commit()
    return result.rowcount > 0


# Project CRUD operations
async def create_project(db: AsyncSession, project: ProjectCreate) -> Project:
    """Create a new project"""
    db_project = Project(**project.dict())
    db.add(db_project)
    await db.commit()
    await db.refresh(db_project)
    return db_project


async def get_project(db: AsyncSession, project_id: int) -> Optional[Project]:
    """Get project by ID"""
    result = await db.execute(
        select(Project)
        .options(selectinload(Project.project_items))
        .where(Project.id == project_id)
    )
    return result.scalar_one_or_none()


async def get_projects(db: AsyncSession, skip: int = 0, limit: int = 100, 
                      user_projects: Optional[List[int]] = None) -> List[Project]:
    """Get list of projects with optional filtering for user access"""
    query = select(Project).where(Project.is_active == True)
    
    if user_projects is not None:
        query = query.where(Project.id.in_(user_projects))
    
    result = await db.execute(
        query.offset(skip).limit(limit).order_by(Project.created_at.desc())
    )
    return result.scalars().all()


async def update_project(db: AsyncSession, project_id: int, project_update: ProjectUpdate) -> Optional[Project]:
    """Update project"""
    update_data = project_update.dict(exclude_unset=True)
    if not update_data:
        return await get_project(db, project_id)
    
    await db.execute(
        update(Project).where(Project.id == project_id).values(**update_data)
    )
    await db.commit()
    return await get_project(db, project_id)


async def delete_project(db: AsyncSession, project_id: int) -> bool:
    """Delete project"""
    result = await db.execute(delete(Project).where(Project.id == project_id))
    await db.commit()
    return result.rowcount > 0


# Project Assignment CRUD operations
async def assign_user_to_project(db: AsyncSession, user_id: int, project_id: int) -> ProjectAssignment:
    """Assign user to project"""
    assignment = ProjectAssignment(user_id=user_id, project_id=project_id)
    db.add(assignment)
    await db.commit()
    await db.refresh(assignment)
    return assignment


async def remove_user_from_project(db: AsyncSession, user_id: int, project_id: int) -> bool:
    """Remove user from project"""
    result = await db.execute(
        delete(ProjectAssignment).where(
            and_(ProjectAssignment.user_id == user_id, 
                 ProjectAssignment.project_id == project_id)
        )
    )
    await db.commit()
    return result.rowcount > 0


async def get_user_project_assignments(db: AsyncSession, user_id: int) -> List[ProjectAssignment]:
    """Get user's project assignments"""
    result = await db.execute(
        select(ProjectAssignment)
        .options(selectinload(ProjectAssignment.project))
        .where(ProjectAssignment.user_id == user_id)
    )
    return result.scalars().all()


# Project Item CRUD operations
async def create_project_item(db: AsyncSession, item: ProjectItemCreate) -> ProjectItem:
    """Create a new project item"""
    db_item = ProjectItem(**item.dict())
    db.add(db_item)
    await db.commit()
    await db.refresh(db_item)
    return db_item


async def get_project_item(db: AsyncSession, item_id: int) -> Optional[ProjectItem]:
    """Get project item by ID"""
    result = await db.execute(
        select(ProjectItem)
        .options(selectinload(ProjectItem.project))
        .where(ProjectItem.id == item_id)
    )
    return result.scalar_one_or_none()


async def get_project_items(db: AsyncSession, project_id: int, skip: int = 0, limit: int = 100) -> List[ProjectItem]:
    """Get project items for a specific project"""
    result = await db.execute(
        select(ProjectItem)
        .where(ProjectItem.project_id == project_id)
        .offset(skip)
        .limit(limit)
        .order_by(ProjectItem.created_at.desc())
    )
    return result.scalars().all()


async def update_project_item(db: AsyncSession, item_id: int, item_update: ProjectItemUpdate) -> Optional[ProjectItem]:
    """Update project item"""
    update_data = item_update.dict(exclude_unset=True)
    if not update_data:
        return await get_project_item(db, item_id)
    
    await db.execute(
        update(ProjectItem).where(ProjectItem.id == item_id).values(**update_data)
    )
    await db.commit()
    return await get_project_item(db, item_id)


async def delete_project_item(db: AsyncSession, item_id: int) -> bool:
    """Delete project item"""
    result = await db.execute(delete(ProjectItem).where(ProjectItem.id == item_id))
    await db.commit()
    return result.rowcount > 0


# Procurement Option CRUD operations
async def create_procurement_option(db: AsyncSession, option: ProcurementOptionCreate) -> ProcurementOption:
    """Create a new procurement option"""
    db_option = ProcurementOption(**option.dict())
    db.add(db_option)
    await db.commit()
    await db.refresh(db_option)
    return db_option


async def get_procurement_option(db: AsyncSession, option_id: int) -> Optional[ProcurementOption]:
    """Get procurement option by ID"""
    result = await db.execute(select(ProcurementOption).where(ProcurementOption.id == option_id))
    return result.scalar_one_or_none()


async def get_procurement_options(db: AsyncSession, skip: int = 0, limit: int = 100, 
                                 item_code: Optional[str] = None) -> List[ProcurementOption]:
    """Get procurement options with optional filtering by item_code"""
    query = select(ProcurementOption).where(ProcurementOption.is_active == True)
    
    if item_code:
        query = query.where(ProcurementOption.item_code == item_code)
    
    result = await db.execute(
        query.offset(skip).limit(limit).order_by(ProcurementOption.created_at.desc())
    )
    return result.scalars().all()


async def get_unique_item_codes(db: AsyncSession) -> List[str]:
    """Get list of unique item codes"""
    result = await db.execute(
        select(ProcurementOption.item_code)
        .where(ProcurementOption.is_active == True)
        .distinct()
        .order_by(ProcurementOption.item_code)
    )
    return [row[0] for row in result.fetchall()]


async def update_procurement_option(db: AsyncSession, option_id: int, 
                                  option_update: ProcurementOptionUpdate) -> Optional[ProcurementOption]:
    """Update procurement option"""
    update_data = option_update.dict(exclude_unset=True)
    if not update_data:
        return await get_procurement_option(db, option_id)
    
    await db.execute(
        update(ProcurementOption).where(ProcurementOption.id == option_id).values(**update_data)
    )
    await db.commit()
    return await get_procurement_option(db, option_id)


async def delete_procurement_option(db: AsyncSession, option_id: int) -> bool:
    """Delete procurement option"""
    result = await db.execute(delete(ProcurementOption).where(ProcurementOption.id == option_id))
    await db.commit()
    return result.rowcount > 0


# Budget Data CRUD operations
async def create_budget_data(db: AsyncSession, budget: BudgetDataCreate) -> BudgetData:
    """Create new budget data"""
    db_budget = BudgetData(**budget.dict())
    db.add(db_budget)
    await db.commit()
    await db.refresh(db_budget)
    return db_budget


async def get_budget_data(db: AsyncSession, time_slot: int) -> Optional[BudgetData]:
    """Get budget data by time slot"""
    result = await db.execute(select(BudgetData).where(BudgetData.time_slot == time_slot))
    return result.scalar_one_or_none()


async def get_all_budget_data(db: AsyncSession) -> List[BudgetData]:
    """Get all budget data ordered by time slot"""
    result = await db.execute(
        select(BudgetData).order_by(BudgetData.time_slot)
    )
    return result.scalars().all()


async def update_budget_data(db: AsyncSession, time_slot: int, 
                           budget_update: BudgetDataUpdate) -> Optional[BudgetData]:
    """Update budget data"""
    update_data = budget_update.dict(exclude_unset=True)
    if not update_data:
        return await get_budget_data(db, time_slot)
    
    await db.execute(
        update(BudgetData).where(BudgetData.time_slot == time_slot).values(**update_data)
    )
    await db.commit()
    return await get_budget_data(db, time_slot)


async def delete_budget_data(db: AsyncSession, time_slot: int) -> bool:
    """Delete budget data"""
    result = await db.execute(delete(BudgetData).where(BudgetData.time_slot == time_slot))
    await db.commit()
    return result.rowcount > 0


# Optimization Result CRUD operations
async def get_optimization_results(db: AsyncSession, run_id: Optional[str] = None, 
                                 skip: int = 0, limit: int = 100) -> List[OptimizationResult]:
    """Get optimization results with optional filtering by run_id"""
    query = select(OptimizationResult)
    
    if run_id:
        query = query.where(OptimizationResult.run_id == run_id)
    
    result = await db.execute(
        query.offset(skip).limit(limit).order_by(OptimizationResult.run_timestamp.desc())
    )
    return result.scalars().all()


async def get_latest_optimization_run(db: AsyncSession) -> Optional[str]:
    """Get the latest optimization run ID"""
    result = await db.execute(
        select(OptimizationResult.run_id)
        .order_by(OptimizationResult.run_timestamp.desc())
        .limit(1)
    )
    row = result.fetchone()
    return str(row[0]) if row else None


# Dashboard and Analytics functions
async def get_dashboard_stats(db: AsyncSession) -> Dict[str, Any]:
    """Get dashboard statistics"""
    # Count active projects
    projects_count = await db.scalar(
        select(func.count(Project.id)).where(Project.is_active == True)
    )
    
    # Count total items across all projects
    items_count = await db.scalar(select(func.count(ProjectItem.id)))
    
    # Count active procurement options
    options_count = await db.scalar(
        select(func.count(ProcurementOption.id)).where(ProcurementOption.is_active == True)
    )
    
    # Sum total budget
    total_budget = await db.scalar(select(func.sum(BudgetData.available_budget)))
    total_budget = total_budget or 0
    
    # Get last optimization timestamp
    last_opt = await db.scalar(
        select(OptimizationResult.run_timestamp)
        .order_by(OptimizationResult.run_timestamp.desc())
        .limit(1)
    )
    
    return {
        "total_projects": projects_count,
        "total_items": items_count,
        "total_procurement_options": options_count,
        "total_budget": total_budget,
        "last_optimization": last_opt,
        "pending_items": 0  # Could be calculated based on business logic
    }


async def get_project_summaries(db: AsyncSession, user_projects: Optional[List[int]] = None) -> List[Dict[str, Any]]:
    """Get project summaries with item counts and estimated costs"""
    query = select(Project).where(Project.is_active == True)
    
    if user_projects is not None:
        query = query.where(Project.id.in_(user_projects))
    
    projects = await db.execute(query)
    summaries = []
    
    for project in projects.scalars():
        # Count items for this project
        item_count = await db.scalar(
            select(func.count(ProjectItem.id)).where(ProjectItem.project_id == project.id)
        )
        
        # Sum quantities for this project
        total_quantity = await db.scalar(
            select(func.sum(ProjectItem.quantity)).where(ProjectItem.project_id == project.id)
        )
        
        # Calculate estimated cost (simplified - could be more sophisticated)
        estimated_cost = await db.scalar(
            select(func.sum(
                ProjectItem.quantity * 
                func.coalesce(ProcurementOption.base_cost, 0)
            ))
            .select_from(ProjectItem)
            .outerjoin(ProcurementOption, 
                      and_(ProjectItem.item_code == ProcurementOption.item_code,
                           ProcurementOption.is_active == True))
            .where(ProjectItem.project_id == project.id)
        )
        
        summaries.append({
            "id": project.id,
            "project_code": project.project_code,
            "name": project.name,
            "item_count": item_count or 0,
            "total_quantity": total_quantity or 0,
            "estimated_cost": estimated_cost or 0
        })
    
    return summaries
