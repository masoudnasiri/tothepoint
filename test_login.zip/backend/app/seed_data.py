"""
Sample data seeding for the Procurement DSS
This module creates default users and sample data for testing
"""

import asyncio
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import AsyncSessionLocal
from app.models import User, Project, ProjectAssignment, ProjectItem, ProcurementOption, BudgetData
from app.auth import get_password_hash
from decimal import Decimal
import logging

logger = logging.getLogger(__name__)


async def create_sample_users(db: AsyncSession):
    """Create default users for testing"""
    # Check if users already exist
    result = await db.execute(select(User).where(User.username == 'admin'))
    if result.scalar_one_or_none():
        logger.info("Sample users already exist, skipping...")
        return
    
    # Create default users
    users_data = [
        {'username': 'admin', 'password': 'admin123', 'role': 'admin'},
        {'username': 'pm1', 'password': 'pm123', 'role': 'pm'},
        {'username': 'proc1', 'password': 'proc123', 'role': 'procurement'},
        {'username': 'finance1', 'password': 'finance123', 'role': 'finance'},
    ]
    
    for user_data in users_data:
        user = User(
            username=user_data['username'],
            password_hash=get_password_hash(user_data['password']),
            role=user_data['role'],
            is_active=True
        )
        db.add(user)
    
    await db.commit()
    logger.info("Sample users created successfully")


async def create_sample_projects(db: AsyncSession):
    """Create sample projects"""
    # Check if projects already exist
    result = await db.execute(select(Project).where(Project.project_code == 'PROJ001'))
    if result.scalar_one_or_none():
        logger.info("Sample projects already exist, skipping...")
        return
    
    # Create sample projects
    projects_data = [
        {'project_code': 'PROJ001', 'name': 'Sample Project 1'},
        {'project_code': 'PROJ002', 'name': 'Sample Project 2'},
    ]
    
    for project_data in projects_data:
        project = Project(
            project_code=project_data['project_code'],
            name=project_data['name'],
            is_active=True
        )
        db.add(project)
    
    await db.commit()
    logger.info("Sample projects created successfully")


async def create_sample_assignments(db: AsyncSession):
    """Create project assignments"""
    # Check if assignments already exist
    result = await db.execute(select(ProjectAssignment).limit(1))
    if result.scalar_one_or_none():
        logger.info("Sample project assignments already exist, skipping...")
        return
    
    # Get PM user
    pm_user = await db.execute(select(User).where(User.username == 'pm1'))
    pm_user = pm_user.scalar_one_or_none()
    
    if not pm_user:
        logger.warning("PM user not found, skipping assignments")
        return
    
    # Get projects
    projects = await db.execute(select(Project))
    projects = projects.scalars().all()
    
    # Create assignments
    for project in projects:
        assignment = ProjectAssignment(
            user_id=pm_user.id,
            project_id=project.id
        )
        db.add(assignment)
    
    await db.commit()
    logger.info("Sample project assignments created successfully")


async def create_sample_procurement_options(db: AsyncSession):
    """Create sample procurement options"""
    # Check if options already exist
    result = await db.execute(select(ProcurementOption).limit(1))
    if result.scalar_one_or_none():
        logger.info("Sample procurement options already exist, skipping...")
        return
    
    # Create sample procurement options
    options_data = [
        {
            'item_code': 'ITEM001',
            'supplier_name': 'Supplier A',
            'base_cost': Decimal('100.00'),
            'lomc_lead_time': 1,
            'discount_bundle_threshold': 50,
            'discount_bundle_percent': Decimal('5.0'),
            'payment_terms': {'type': 'cash', 'discount_percent': 5}
        },
        {
            'item_code': 'ITEM001',
            'supplier_name': 'Supplier B',
            'base_cost': Decimal('95.00'),
            'lomc_lead_time': 2,
            'discount_bundle_threshold': 100,
            'discount_bundle_percent': Decimal('10.0'),
            'payment_terms': {
                'type': 'installments',
                'schedule': [
                    {'due_offset': 0, 'percent': 40},
                    {'due_offset': 1, 'percent': 30},
                    {'due_offset': 2, 'percent': 30}
                ]
            }
        },
        {
            'item_code': 'ITEM002',
            'supplier_name': 'Supplier A',
            'base_cost': Decimal('150.00'),
            'lomc_lead_time': 1,
            'discount_bundle_threshold': 25,
            'discount_bundle_percent': Decimal('3.0'),
            'payment_terms': {'type': 'cash', 'discount_percent': 3}
        },
        {
            'item_code': 'ITEM003',
            'supplier_name': 'Supplier C',
            'base_cost': Decimal('200.00'),
            'lomc_lead_time': 3,
            'discount_bundle_threshold': 10,
            'discount_bundle_percent': Decimal('15.0'),
            'payment_terms': {
                'type': 'installments',
                'schedule': [
                    {'due_offset': 0, 'percent': 50},
                    {'due_offset': 1, 'percent': 50}
                ]
            }
        }
    ]
    
    for option_data in options_data:
        option = ProcurementOption(
            item_code=option_data['item_code'],
            supplier_name=option_data['supplier_name'],
            base_cost=option_data['base_cost'],
            lomc_lead_time=option_data['lomc_lead_time'],
            discount_bundle_threshold=option_data['discount_bundle_threshold'],
            discount_bundle_percent=option_data['discount_bundle_percent'],
            payment_terms=option_data['payment_terms'],
            is_active=True
        )
        db.add(option)
    
    await db.commit()
    logger.info("Sample procurement options created successfully")


async def create_sample_budget_data(db: AsyncSession):
    """Create sample budget data"""
    # Check if budget data already exists
    result = await db.execute(select(BudgetData).limit(1))
    if result.scalar_one_or_none():
        logger.info("Sample budget data already exists, skipping...")
        return
    
    # Create sample budget data
    budget_data = [
        {'time_slot': 1, 'available_budget': Decimal('100000.00')},
        {'time_slot': 2, 'available_budget': Decimal('150000.00')},
        {'time_slot': 3, 'available_budget': Decimal('120000.00')},
        {'time_slot': 4, 'available_budget': Decimal('180000.00')},
        {'time_slot': 5, 'available_budget': Decimal('200000.00')},
        {'time_slot': 6, 'available_budget': Decimal('160000.00')},
    ]
    
    for budget in budget_data:
        budget_entry = BudgetData(
            time_slot=budget['time_slot'],
            available_budget=budget['available_budget']
        )
        db.add(budget_entry)
    
    await db.commit()
    logger.info("Sample budget data created successfully")


async def create_sample_project_items(db: AsyncSession):
    """Create sample project items"""
    # Check if project items already exist
    result = await db.execute(select(ProjectItem).limit(1))
    if result.scalar_one_or_none():
        logger.info("Sample project items already exist, skipping...")
        return
    
    # Get projects
    projects = await db.execute(select(Project))
    projects = projects.scalars().all()
    
    if not projects:
        logger.warning("No projects found, skipping project items")
        return
    
    # Create sample project items
    items_data = [
        {'project_code': 'PROJ001', 'item_code': 'ITEM001', 'item_name': 'Sample Item 1', 'quantity': 10, 'must_buy_time': 2, 'allowed_times': '1,2,3', 'external_purchase': True},
        {'project_code': 'PROJ001', 'item_code': 'ITEM002', 'item_name': 'Sample Item 2', 'quantity': 5, 'must_buy_time': None, 'allowed_times': '2,4', 'external_purchase': False},
        {'project_code': 'PROJ002', 'item_code': 'ITEM003', 'item_name': 'Sample Item 3', 'quantity': 8, 'must_buy_time': 3, 'allowed_times': '1,3,5', 'external_purchase': True},
    ]
    
    for item_data in items_data:
        # Find the project
        project = next((p for p in projects if p.project_code == item_data['project_code']), None)
        if not project:
            continue
        
        item = ProjectItem(
            project_id=project.id,
            item_code=item_data['item_code'],
            item_name=item_data['item_name'],
            quantity=item_data['quantity'],
            must_buy_time=item_data['must_buy_time'],
            allowed_times=item_data['allowed_times'],
            external_purchase=item_data['external_purchase']
        )
        db.add(item)
    
    await db.commit()
    logger.info("Sample project items created successfully")


async def seed_sample_data():
    """Seed all sample data"""
    async with AsyncSessionLocal() as db:
        try:
            logger.info("Starting to seed sample data...")
            
            await create_sample_users(db)
            await create_sample_projects(db)
            await create_sample_assignments(db)
            await create_sample_procurement_options(db)
            await create_sample_budget_data(db)
            await create_sample_project_items(db)
            
            logger.info("Sample data seeding completed successfully!")
            
        except Exception as e:
            logger.error(f"Error seeding sample data: {str(e)}")
            await db.rollback()
            raise


if __name__ == "__main__":
    asyncio.run(seed_sample_data())
